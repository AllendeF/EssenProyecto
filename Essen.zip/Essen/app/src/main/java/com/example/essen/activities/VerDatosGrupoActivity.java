package com.example.essen.activities;

public class VerDatosGrupoActivity {
}
